<?php

	echo "BERHASIL!";
?>